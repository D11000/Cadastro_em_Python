def editar():
        editar = str(input("digite o nome que vc quer editar:"))
        arquivo = open('arqcad.txt', 'r')
        linhas= arquivo.readline()
        print(len(linhas))
        print(linhas)
        for editar in linhas :
            if True:
                print("achei")









        arquivo.close()

editar()